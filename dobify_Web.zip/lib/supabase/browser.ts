"use client"

import { supabase } from "../supabase"

export function getBrowserSupabase() {
  return supabase
}

